<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class CustomProductFlag extends ObjectModel
{
    public $id_custom_product_flags;
    public $name;
    public $condition_type;
    public $condition_value;

    public static $definition = [
        'table' => 'custom_product_flags',
        'primary' => 'id_custom_product_flags',
        'fields' => [
            'id_custom_product_flags' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'name' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 255],
            'condition_type' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 50],
            'condition_value' => ['type' => self::TYPE_STRING, 'validate' => 'isAnything', 'size' => 255],
        ],
    ];
}