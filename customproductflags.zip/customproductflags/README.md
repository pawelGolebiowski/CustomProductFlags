Moduł Custom Product Flags dla PrestaShop 1.7

Opis

Ten moduł pozwala na dodawanie niestandardowych flag do produktów w Twoim sklepie PrestaShop 1.7. Możesz przypisać flagi do pojedynczych produktów, wszystkich produktów w kategorii lub wszystkich produktów w sklepie.

Instalacja

Pobierz plik customproductflags.zip.
Przejdź do panelu administracyjnego PrestaShop > Moduły > Menedżer modułów.
Kliknij „Wgraj moduł” i wybierz pobrany plik zip.
Po załadowaniu kliknij „Zainstaluj”, aby zainstalować moduł.
Konfiguracja

Po instalacji przejdź do Katalog > Flagi Produktów w panelu administracyjnym. Tutaj możesz dodawać, edytować i usuwać niestandardowe flagi. Aby przypisać flagi do produktów:

Przejdź do strony edycji produktu i przewiń do sekcji „Flagi Produktów”.
Wybierz flagi, które chcesz przypisać, i zapisz produkt.
Aby przypisać flagę do wszystkich produktów w kategorii lub wszystkich produktów w sklepie:

Przejdź do Katalog > Flagi Produktów.
Skorzystaj z akcji „Przypisz do kategorii” lub „Przypisz do wszystkich produktów” obok każdej flagi.
Funkcje

Twórz niestandardowe flagi z własnymi nazwami
Przypisuj flagi do pojedynczych produktów
Przypisuj flagi do wszystkich produktów w kategorii
Przypisuj flagi do wszystkich produktów w sklepie
Wyświetlaj flagi na stronach produktów i listach produktów