<?php
$sql = array();

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'custom_product_flags` (
    `id_custom_product_flags` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `condition_type` varchar(50) NOT NULL,
    `condition_value` varchar(255) NOT NULL,
    PRIMARY KEY (`id_custom_product_flags`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'custom_product_flags_product` (
    `id_custom_product_flags` int(11) NOT NULL,
    `id_product` int(11) NOT NULL,
    PRIMARY KEY (`id_custom_product_flags`, `id_product`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}