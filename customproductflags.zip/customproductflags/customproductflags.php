<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class CustomProductFlags extends Module
{
    public function __construct()
    {
        $this->name = 'customproductflags';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Paweł Gołębiowski';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '1.7.0.0',
            'max' => _PS_VERSION_
        ];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Custom Product Flags');
        $this->description = $this->l('Adds custom flags to products');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
        spl_autoload_register(array($this, 'autoloadClass'));
    }

    public function autoloadClass($className)
    {
        $classPath = _PS_MODULE_DIR_ . $this->name . '/classes/' . $className . '.php';
        if (file_exists($classPath)) {
            require_once $classPath;
        }
    }

    public function install()
    {
        include(dirname(__FILE__).'/sql/install.php');

        return parent::install() &&
            $this->registerHook('displayProductListReviews') &&
            $this->registerHook('actionProductUpdate') &&
            $this->registerHook('actionCategoryUpdate') &&
            $this->registerHook('actionObjectProductAddAfter') &&
            $this->registerHook('displayBackOfficeHeader');
    }

    public function uninstall()
    {
        include(dirname(__FILE__).'/sql/uninstall.php');

        return parent::uninstall();
    }

    public function getContent()
    {
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminCustomProductFlags'));
    }

    public function hookDisplayProductListReviews($params)
    {
        $product_id = $params['product']['id_product'];
        $flags = $this->getProductFlags($product_id);

        $this->context->smarty->assign([
            'flags' => $flags,
        ]);

        return $this->display(__FILE__, 'views/templates/hook/product_flags.tpl');
    }

    public function hookActionProductUpdate($params)
    {
        $this->updateProductFlags($params['id_product']);
    }

    public function hookActionCategoryUpdate($params)
    {
        $this->updateCategoryFlags($params['category']->id);
    }

    public function hookActionObjectProductAddAfter($params)
    {
        $this->updateProductFlags($params['object']->id);
    }

    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('controller') == 'AdminCustomProductFlags') {
            $this->context->controller->addJS($this->_path.'views/js/admin.js');
            $this->context->controller->addCSS($this->_path.'views/css/admin.css');
        }
    }

    private function getProductFlags($id_product)
    {
        $sql = 'SELECT * FROM '._DB_PREFIX_.'custom_product_flags WHERE id_product = '.(int)$id_product;
        return Db::getInstance()->executeS($sql);
    }

    public function updateProductFlags($id_product)
    {
        $sql = 'SELECT id_custom_product_flags FROM '._DB_PREFIX_.'custom_product_flags_product WHERE id_product = '.(int)$id_product;
        $assigned_flags = Db::getInstance()->executeS($sql);

        $sql = 'SELECT id_custom_product_flags FROM '._DB_PREFIX_.'custom_product_flags';
        $all_flags = Db::getInstance()->executeS($sql);

        foreach ($all_flags as $flag) {
            $should_assign = $this->checkFlagConditions($id_product, $flag['id_custom_product_flags']);
            $is_assigned = in_array($flag['id_custom_product_flags'], array_column($assigned_flags, 'id_custom_product_flags'));

            if ($should_assign && !$is_assigned) {
                Db::getInstance()->insert('custom_product_flags_product', [
                    'id_custom_product_flags' => (int)$flag['id_custom_product_flags'],
                    'id_product' => (int)$id_product
                ]);
            } elseif (!$should_assign && $is_assigned) {
                Db::getInstance()->delete('custom_product_flags_product',
                    'id_custom_product_flags = '.(int)$flag['id_custom_product_flags'].' AND id_product = '.(int)$id_product
                );
            }
        }
    }

    private function updateCategoryFlags($id_category)
    {
        $products = Product::getProducts($this->context->language->id, 0, 0, 'id_product', 'ASC', $id_category);
        foreach ($products as $product) {
            $this->updateProductFlags($product['id_product']);
        }
    }

    private function checkFlagConditions($id_product, $id_flag)
    {
        $product = new Product($id_product);
        $flag = new CustomProductFlag($id_flag);

        switch ($flag->condition_type) {
            case 'price':
                return $product->price < $flag->condition_value;
            case 'quantity':
                return $product->quantity < $flag->condition_value;
            case 'category':
                return in_array($flag->condition_value, $product->getCategories());
            default:
                return false;
        }
    }
}