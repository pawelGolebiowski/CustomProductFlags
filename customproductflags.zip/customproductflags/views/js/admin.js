$(document).ready(function() {
    // Add your custom JavaScript for the admin page here
});