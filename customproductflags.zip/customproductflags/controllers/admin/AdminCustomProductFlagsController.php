<?php

class AdminCustomProductFlagsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'custom_product_flags';
        $this->className = 'CustomProductFlag';
        $this->lang = false;

        parent::__construct();

        $this->fields_list = [
            'id_custom_product_flags' => [
                'title' => $this->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-xs'
            ],
            'name' => [
                'title' => $this->l('Name'),
                'align' => 'left',
            ],
        ];

        $this->bulk_actions = [
            'delete' => [
                'text' => $this->l('Delete selected'),
                'confirm' => $this->l('Delete selected items?'),
                'icon' => 'icon-trash'
            ]
        ];

        $this->fields_list['condition_type'] = [
            'title' => $this->l('Condition Type'),
            'align' => 'left',
        ];
        $this->fields_list['condition_value'] = [
            'title' => $this->l('Condition Value'),
            'align' => 'left',
        ];

        $this->addRowAction('edit');
        $this->addRowAction('delete');
    }

    public function renderForm()
    {
        $this->fields_form = [
            'legend' => [
                'title' => $this->l('Custom Product Flag'),
                'icon' => 'icon-tag'
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->l('Name'),
                    'name' => 'name',
                    'required' => true
                ],
                [
                    'type' => 'select',
                    'label' => $this->l('Condition Type'),
                    'name' => 'condition_type',
                    'options' => [
                        'query' => [
                            ['id' => 'price', 'name' => $this->l('Price')],
                            ['id' => 'quantity', 'name' => $this->l('Quantity')],
                            ['id' => 'category', 'name' => $this->l('Category')],
                        ],
                        'id' => 'id',
                        'name' => 'name'
                    ]
                ],
                [
                    'type' => 'text',
                    'label' => $this->l('Condition Value'),
                    'name' => 'condition_value',
                    'desc' => $this->l('Enter a value for the selected condition type')
                ],
            ],
            'submit' => [
                'title' => $this->l('Save'),
            ]
        ];

        return parent::renderForm();
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAdd'.$this->table)) {
            $obj = $this->loadObject(true);
            $obj->name = Tools::getValue('name');
            $obj->condition_type = Tools::getValue('condition_type');
            $obj->condition_value = Tools::getValue('condition_value');
            $obj->save();

            $products = Product::getProducts($this->context->language->id, 0, 0, 'id_product', 'ASC');
            foreach ($products as $product) {
                $this->module->updateProductFlags($product['id_product']);
            }

            $this->confirmations[] = $this->l('Flag saved and applied to relevant products.');
        }

        return parent::postProcess();
    }
}